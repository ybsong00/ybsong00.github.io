#ifndef QX_SOURCE_FILE_H
#define QX_SOURCE_FILE_H

#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <WinDef.h>
#include <math.h>

#define QX_DEF_PADDING                  128
#define QX_DEF_THRESHOLD_ZERO			1e-6
#define QX_DEF_CHAR_MAX					255
#define QX_DEF_SHORT_MAX				65535

inline int qx_round(double in_x) { if(in_x<0) return (int)(in_x-0.5); else return (int)(in_x+0.5); }


//-------------------------------------------------------load/save image---------------------------------------
bool qx_image_size_png(const char*filename,int &h,int &w);
bool qx_loadimage_png(const char*filename,unsigned char*image,int h,int w,bool use_rgb);
void saveimage_pgm(char *file_name,unsigned char **image,int h,int w,int scale=1);
void write_binary_pgm(char* file_name,unsigned char* image,int h,int w);

//-------------------------------------------------------memory operation--------------------------------------
inline unsigned char** qx_allocu(int r,int c,int padding=QX_DEF_PADDING)
{
	unsigned char *a,**p;
	a=(unsigned char*) malloc(sizeof(unsigned char)*(r*c+padding));
	if(a==NULL) {printf("qx_allocu() fail, Memory is too huge, fail.\n"); getchar(); exit(0); }
	p=(unsigned char**) malloc(sizeof(unsigned char*)*r);
	for(int i=0;i<r;i++) p[i]= &a[i*c];
	return(p);
}
inline void qx_freeu(unsigned char **p)
{
	if(p!=NULL)
	{
		free(p[0]);
		free(p);
		p=NULL;
	}
}
inline unsigned char *** qx_allocu_3(int n,int r,int c,int padding=QX_DEF_PADDING)
{
	unsigned char *a,**p,***pp;
    int rc=r*c;
    int i,j;
	a=(unsigned char*) malloc(sizeof(unsigned char )*(n*rc+padding));
	if(a==NULL) {printf("qx_allocu_3() fail, Memory is too huge, fail.\n"); getchar(); exit(0); }
    p=(unsigned char**) malloc(sizeof(unsigned char*)*n*r);
    pp=(unsigned char***) malloc(sizeof(unsigned char**)*n);
    for(i=0;i<n;i++) 
        for(j=0;j<r;j++) 
            p[i*r+j]=&a[i*rc+j*c];
    for(i=0;i<n;i++) 
        pp[i]=&p[i*r];
    return(pp);
}
inline void qx_freeu_3(unsigned char ***p)
{
	if(p!=NULL)
	{
		free(p[0][0]);
		free(p[0]);
		free(p);
		p=NULL;
	}
}
inline double** qx_allocd(int r,int c,int padding=QX_DEF_PADDING)
{
	double *a,**p;
	a=(double*) malloc(sizeof(double)*(r*c+padding));
	if(a==NULL) {printf("qx_allocd() fail, Memory is too huge, fail.\n"); getchar(); exit(0); }
	p=(double**) malloc(sizeof(double*)*r);
	for(int i=0;i<r;i++) p[i]= &a[i*c];
	return(p);
}
inline void qx_freed(double **p)
{
	if(p!=NULL)
	{
		free(p[0]);
		free(p);
		p=NULL;
	}
}
inline double *** qx_allocd_3(int n,int r,int c,int padding=QX_DEF_PADDING)
{
	double *a,**p,***pp;
    int rc=r*c;
    int i,j;
	a=(double*) malloc(sizeof(double)*(n*rc+padding));
	if(a==NULL) {printf("qx_allocd_3() fail, Memory is too huge, fail.\n"); getchar(); exit(0); }
    p=(double**) malloc(sizeof(double*)*n*r);
    pp=(double***) malloc(sizeof(double**)*n);
    for(i=0;i<n;i++) 
        for(j=0;j<r;j++) 
            p[i*r+j]=&a[i*rc+j*c];
    for(i=0;i<n;i++) 
        pp[i]=&p[i*r];
    return(pp);
}
inline void qx_freed_3(double ***p)
{
	if(p!=NULL)
	{
		free(p[0][0]);
		free(p[0]);
		free(p);
		p=NULL;
	}
}
inline int*** qx_alloci_3(int n,int r,int c,int padding=QX_DEF_PADDING)
{
	int *a,**p,***pp;
    int rc=r*c;
    int i,j;
	a=(int*) malloc(sizeof(int)*(n*rc+padding));
	if(a==NULL) {printf("qx_alloci_3() fail, Memory is too huge, fail.\n"); getchar(); exit(0); }
    p=(int**) malloc(sizeof(int*)*n*r);
    pp=(int***) malloc(sizeof(int**)*n);
    for(i=0;i<n;i++) 
        for(j=0;j<r;j++) 
            p[i*r+j]=&a[i*rc+j*c];
    for(i=0;i<n;i++) 
        pp[i]=&p[i*r];
    return(pp);
}
inline void qx_freei_3(int ***p)
{
	if(p!=NULL)
	{
		free(p[0][0]);
		free(p[0]);
		free(p);
		p=NULL;
	}
}

//----------------------------------------------------sketch shift vector----------------------------------------
struct sketch_shift_vector
{
	int image_id;
	int dx;
	int dy;
};

inline sketch_shift_vector***qx_alloc_ssv_3(int n,int r,int c,int padding=QX_DEF_PADDING)
{
	sketch_shift_vector *a,**p,***pp;
    int rc=r*c;
    int i,j;
	a=(sketch_shift_vector*) malloc(sizeof(sketch_shift_vector)*(n*rc+padding));
	if(a==NULL) {printf("qx_allocd_3() fail, Memory is too huge, fail.\n"); getchar(); exit(0); }
    p=(sketch_shift_vector**) malloc(sizeof(sketch_shift_vector*)*n*r);
    pp=(sketch_shift_vector***) malloc(sizeof(sketch_shift_vector**)*n);
    for(i=0;i<n;i++) 
        for(j=0;j<r;j++) 
            p[i*r+j]=&a[i*rc+j*c];
    for(i=0;i<n;i++) 
        pp[i]=&p[i*r];
    return(pp);
}
inline void qx_free_ssv_3(sketch_shift_vector ***p)
{
	if(p!=NULL)
	{
		free(p[0][0]);
		free(p[0]);
		free(p);
		p=NULL;
	}
}

//-------------------------------------------------------box filtering operation--------------------------------
void boxcar_sliding_window(double**out,double**in,double**temp,double*temp_1w,double sigma_spatial,int h,int w);
void boxcar_sliding_window_x(double*out,double*in,int h,int w,int radius);
void boxcar_sliding_window_y(double *out,double *in,double*temp_1w,int h,int w,int radius);

//-------------------------------------------------------ax=b solver--------------------------------------------
class qx_conjugated_gradient_double
{
public:
	qx_conjugated_gradient_double();
	~qx_conjugated_gradient_double();
	void clean();
	int init(int len); /*n*len: ata[len X len]*/ 
	double solver(double *x,double **a,double *b,int n,int m,double accuracy=1.0e-6,bool is_symmetry=false);//A[n][m], AtA[m][m]. If symmetric, only m is valid;
private:
	double **m_ata,*m_atb,*m_d,*m_ad,*m_r;
	int m_len;
	double solver_symmetry(double **ata,double *atb,double *x,double *d,double *r,double *ad,int len,double accuracy);
};
void qx_ata_dn(double **ata,double **a,int n,int m);
void qx_atb_dn(double *atb,double **a,double *b,int n,int m);
inline double qx_dot_dn(double *a,double *b,int n)
{
	double out=0;
	for(int i=0;i<n;i++) out+=a[i]*b[i];
	return(out);
}
inline double qx_norm_dn(double*a,int n){double *b=a; double ss=qx_dot_dn(a,b,n);return(sqrt(ss));}


//------------------------------------------------------Luminance remapping----------------------------------------
void vec_max_val(double &max_val,double *in,int len);
void vec_min_val(double &min_val,double *in,int len);
void image_stretch(double**image,int h,int w);
void luma_remap_global(unsigned char**out,unsigned char**in,double**temp,int h,int w);


void saveimage_ppm(char *filename,unsigned char ***image,int h,int w,int scale=1);
void write_ascii_ppm(char* filename,unsigned char *image,int h,int w);
#endif

