#include "face_sketch_synthesis.h"

sketch_synthesis_ssd_release::sketch_synthesis_ssd_release()
{
	m_load_image=NULL;
	m_test_photo=NULL;
	m_test_photo_add=NULL;
	m_training_photo_add=NULL;
	m_training_sketch_add=NULL;

	m_temp_u2=NULL;
	m_temp_d2=NULL;
	m_temp_i2=NULL;
	m_min_cost_pool=NULL;
	m_disparity_pool=NULL;
	m_shift_vector=NULL;

	m_AtA=NULL;
	m_AtB=NULL;
	m_xx=NULL;
}

sketch_synthesis_ssd_release::~sketch_synthesis_ssd_release()
{
	clean();
}

void sketch_synthesis_ssd_release::clean()
{
	qx_freeu(m_load_image);						m_load_image=NULL;
	qx_freeu(m_test_photo);						m_test_photo=NULL;
	qx_freeu(m_test_photo_add);					m_test_photo_add=NULL;
	qx_freeu_3(m_training_photo_add);			m_training_photo_add=NULL;
	qx_freeu_3(m_training_sketch_add);			m_training_sketch_add=NULL;

	qx_freeu_3(m_temp_u2);						m_temp_u2=NULL;
	qx_freed_3(m_temp_d2);						m_temp_d2=NULL;
	qx_freei_3(m_temp_i2);						m_temp_i2=NULL;
	qx_freed_3(m_min_cost_pool);				m_min_cost_pool=NULL;
	qx_freei_3(m_disparity_pool);				m_disparity_pool=NULL;
	qx_free_ssv_3(m_shift_vector);				m_shift_vector=NULL;

	qx_freed(m_AtA);							m_AtA=NULL;
	delete[]m_AtB;								m_AtB=NULL;
	qx_freed_3(m_xx);							m_xx=NULL;
}

int sketch_synthesis_ssd_release::init(char*folder_photo,char*folder_sketch,int training_num,int search_radius,int border,int radius_denoising,int nr_candidate,double sigma_spatial)
{
	m_training_num=training_num;m_search_radius=search_radius;m_add_border=border;m_denoise_radius=radius_denoising;m_candidate_num=nr_candidate;m_sigma_spatial=sigma_spatial;
	m_roi[0]=75;m_roi[1]=125;m_roi[2]=125;m_roi[3]=200;	

	char str[900];int str_len=900;
	sprintf_s(str,str_len,"%s/00.png",folder_photo);
	qx_image_size_png(str,m_h,m_w);
	m_h_add=m_h+2*m_add_border;m_w_add=m_w+2*m_add_border;

	m_load_image=qx_allocu(m_h,m_w);
	m_test_photo=qx_allocu(m_h,m_w);
	m_test_photo_add=qx_allocu(m_h_add,m_w_add);
	m_training_photo_add=qx_allocu_3(m_training_num,m_h_add,m_w_add);
	m_training_sketch_add=qx_allocu_3(m_training_num,m_h_add,m_w_add);

	m_temp_u2=qx_allocu_3(1,m_h,m_w);
	m_temp_d2=qx_allocd_3(4,m_h,m_w);
	m_temp_i2=qx_alloci_3(1,m_h,m_w);
	m_min_cost_pool=qx_allocd_3(m_training_num,m_h,m_w);
	m_disparity_pool=qx_alloci_3(m_training_num,m_h,m_w);
	m_shift_vector=qx_alloc_ssv_3(m_h,m_w,m_candidate_num);

	m_mean_of_training=0;
	for(int i=0;i<m_training_num;i++)
	{
		sprintf_s(str,str_len,"%s/%02d.png",folder_sketch,i);
		qx_loadimage_png(str,m_load_image[0],m_h,m_w,false);
		image_padding(m_training_sketch_add[i],m_load_image,m_h_add,m_w_add,m_h,m_w,m_add_border);
		sprintf_s(str,str_len,"%s/%02d.png",folder_photo,i);
		qx_loadimage_png(str,m_load_image[0],m_h,m_w,false);		
		for(int y=m_roi[2];y<=m_roi[3];y++)	for(int x=m_roi[0];x<=m_roi[1];x++)	m_mean_of_training+=(double)m_load_image[y][x];
		image_padding(m_training_photo_add[i],m_load_image,m_h_add,m_w_add,m_h,m_w,m_add_border);
	}
	m_mean_of_training/=m_training_num*(m_roi[3]-m_roi[2]+1)*(m_roi[1]-m_roi[0]+1);

	m_AtA=qx_allocd(m_candidate_num,m_candidate_num);
	m_AtB=new double[m_candidate_num];
	m_xx=qx_allocd_3(m_h,m_w,m_candidate_num);
	m_cg.init(m_candidate_num);

	return 0;
}

int sketch_synthesis_ssd_release::process(unsigned char**sketch_out,unsigned char**image_in)
{
	initial_image(image_in);
	knn_search();
	linear_regression();
	denoising(sketch_out);

	return 0;
}


void sketch_synthesis_ssd_release::image_padding(unsigned char**out,unsigned char**in,int h_add,int w_add,int h,int w,int border)
{
	for(int y=0;y<h;y++)	memcpy(&out[y+m_add_border][m_add_border],in[y],sizeof(unsigned char)*m_w);
	for(int x=border;x<w+border;x++)
	{
		for(int y=0;y<border;y++)	out[y][x]=out[border][x];
		for(int y=h+border;y<h+2*border;y++)	out[y][x]=out[h+border-1][x];
	}
	for(int y=0;y<h+2*border;y++)
	{
		for(int x=0;x<border;x++)	out[y][x]=out[y][border];
		for(int x=w+border;x<w+2*border;x++)	out[y][x]=out[y][w+border-1];
	}
}

void sketch_synthesis_ssd_release::initial_image(unsigned char**in)
{
	memcpy(m_test_photo[0],in[0],sizeof(unsigned char)*m_h*m_w);
	
	double mean_roi=0,scalar=1;
	for(int y=m_roi[2];y<=m_roi[3];y++)	for(int x=m_roi[0];x<=m_roi[1];x++)	mean_roi+=m_test_photo[y][x];
	mean_roi/=(m_roi[3]-m_roi[2]+1)*(m_roi[1]-m_roi[0]+1);
	scalar=m_mean_of_training/mean_roi;
	for(int y=0;y<m_h;y++)	for(int x=0;x<m_w;x++)	m_test_photo[y][x]=(unsigned char)min(255,(double)m_test_photo[y][x]*scalar);
	image_padding(m_test_photo_add,m_test_photo,m_h_add,m_w_add,m_h,m_w,m_add_border);
}

void sketch_synthesis_ssd_release::knn_search()
{
	double**cost_slice=m_temp_d2[0];
	double**temp=m_temp_d2[1];
	double**temp1w=m_temp_d2[2];
	double**min_cost=m_temp_d2[3];
	unsigned char**right_shifted_photo=m_temp_u2[0];
	int**disparity_slice=m_temp_i2[0];

	int r=m_search_radius;
	for(int k=0;k<m_training_num;k++)
	{
		for(int y=0;y<m_h;y++)	for(int x=0;x<m_w;x++)	min_cost[y][x]=QX_DEF_SHORT_MAX;
		for(int dy=-r;dy<=r;dy++)	for(int dx=-r;dx<=r;dx++)
		{
			for(int y=0;y<m_h;y++)	memcpy(right_shifted_photo[y],&m_training_photo_add[k][y+dy+m_add_border][dx+m_add_border],sizeof(unsigned char)*m_w);
			for(int y=0;y<m_h;y++)	for(int x=0;x<m_w;x++)	cost_slice[y][x]=abs((double)right_shifted_photo[y][x]-(double)m_test_photo[y][x]);
			boxcar_sliding_window(cost_slice,cost_slice,temp,temp1w[0],m_sigma_spatial,m_h,m_w);
			for(int y=0;y<m_h;y++)	for(int x=0;x<m_w;x++)
			{
				if(cost_slice[y][x]<min_cost[y][x])
				{
					min_cost[y][x]=cost_slice[y][x];
					disparity_slice[y][x]=(dy+r)*(2*r+1)+(dx+r);
				}
			}
		}
		for(int y=0;y<m_h;y++)	for(int x=0;x<m_w;x++)
		{
			m_min_cost_pool[k][y][x]=min_cost[y][x];
			m_disparity_pool[k][y][x]=disparity_slice[y][x];
		}
	}

	for(int y=0;y<m_h;y++)	for(int x=0;x<m_w;x++)
	{
		for(int i=0;i<m_candidate_num;i++)
		{
			double cost_min=QX_DEF_SHORT_MAX;
			int image_id=QX_DEF_SHORT_MAX;	
			for(int k=0;k<m_training_num;k++)
			{
				if(m_min_cost_pool[k][y][x]<cost_min)
				{
					cost_min=m_min_cost_pool[k][y][x];
					image_id=k;
				}
			}
			m_shift_vector[y][x][i].dy=m_disparity_pool[image_id][y][x]/(2*r+1)-r;
			m_shift_vector[y][x][i].dx=m_disparity_pool[image_id][y][x]%(2*r+1)-r;
			m_shift_vector[y][x][i].image_id=image_id;
			m_min_cost_pool[image_id][y][x]=QX_DEF_SHORT_MAX;
		}
	}
}

void sketch_synthesis_ssd_release::linear_regression()
{
	int r=m_search_radius;
	for(int y=0;y<m_h;y++)	for(int x=0;x<m_w;x++)
	{
		memset(m_AtA[0],0,sizeof(double)*m_candidate_num*m_candidate_num);
		memset(m_AtB,0,sizeof(double)*m_candidate_num);
		for(int m=0;m<m_candidate_num;m++)
		{
			unsigned char**image_m=m_training_photo_add[m_shift_vector[y][x][m].image_id];
			int m_center_y=m_shift_vector[y][x][m].dy+y+m_add_border;
			int m_center_x=m_shift_vector[y][x][m].dx+x+m_add_border;
			for(int n=0;n<m_candidate_num;n++)
			{
				unsigned char**image_n=m_training_photo_add[m_shift_vector[y][x][n].image_id];
				int n_center_y=m_shift_vector[y][x][n].dy+y+m_add_border;
				int n_center_x=m_shift_vector[y][x][n].dx+x+m_add_border;
				for(int j=-r;j<=r;j++)	for(int i=-r;i<=r;i++)
				{
					m_AtA[m][n]+=(double)image_m[m_center_y+j][m_center_x+i]*(double)image_n[n_center_y+j][n_center_x+i];
					if(m==n)	m_AtA[m][n]+=(2*r+1)*(2*r+1);
				}
			}
			for(int j=-r;j<=r;j++)	for(int i=-r;i<=r;i++)	m_AtB[m]+=(double)image_m[m_center_y+j][m_center_x+i]*(double)m_test_photo_add[y+m_add_border+j][x+m_add_border+i];
		}		
		m_cg.solver(m_xx[y][x],m_AtA,m_AtB,m_candidate_num,m_candidate_num,QX_DEF_THRESHOLD_ZERO,true);
	}
}

void sketch_synthesis_ssd_release::denoising(unsigned char**output_sketch)
{
	for(int y=0;y<m_h;y++)	for(int x=0;x<m_w;x++)	output_sketch[y][x]=255;
	int r=m_denoise_radius;
	for(int y=0;y<m_h;y++)	for(int x=0;x<m_w;x++)
	{
		int ymin=max(0,y-r);
		int ymax=min(m_h-1,y+r);
		int xmin=max(0,x-r);
		int xmax=min(m_w-1,x+r);
		double sum_value=0;
		double sum_weight=0;
		for(int yi=ymin;yi<=ymax;yi++)	for(int xi=xmin;xi<=xmax;xi++)
		{
			double result=0;
			double*xx=m_xx[yi][xi];
			for(int k=0;k<m_candidate_num;k++)
			{
				int patch_k=m_shift_vector[yi][xi][k].image_id;
				int center_y=m_shift_vector[yi][xi][k].dy+y+m_add_border;
				int center_x=m_shift_vector[yi][xi][k].dx+x+m_add_border;
				result+=(double)m_training_sketch_add[patch_k][center_y][center_x]*xx[k];
			}
			double weight=1;
			sum_weight+=weight;
			sum_value+=weight*result;
		}
		output_sketch[y][x]=(unsigned char)min(255,max(0,sum_value/sum_weight));
	}
}