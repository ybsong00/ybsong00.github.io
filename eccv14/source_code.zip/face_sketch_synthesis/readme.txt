The face sketch synthesis (SSD) code is a C++ implementation of our ECCV 2014 paper.

The code is self-contained and has been successfully compiled in Visual Studio 2012 (under 32-bit Windows 7 release mode).

The training dataset by courtesy of CUHK face sketch dataset (http://mmlab.ie.cuhk.edu.hk/archive/facesketch.html).

The code can only handle rectified face photos (h=250, w=200, left eye position (x=75,y=125), right eye position (x=125,y=125)). If you try to synthesize sketches on other photos please rectify them first.

Note that the code is only for academic use, please do not distribute it for other purposes.

If you use the code, please cite the following two papers:

1.  Face Photo-Sketch Synthesis and Recognition. 		Wang et al. PAMI 2009.
2.  Real-Time Exemplar-based Face Sketch Synthesis. 	Song et al. ECCV 2014.