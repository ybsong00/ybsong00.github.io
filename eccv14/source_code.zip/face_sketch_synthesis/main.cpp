#include "source_file.h"
#include "face_sketch_synthesis.h"

void face_sketch();

void main()
{	
	face_sketch();
}

void face_sketch()
{
	char str[900];
	int str_len=900,h,w;

	char*folder_photo="dataset/CUHK/training/photos";
	char*folder_sketch="dataset/CUHK/training/sketches";
	qx_image_size_png("dataset/CUHK/training/photos/00.png",h,w);

	sketch_synthesis_ssd_release ssd;
	ssd.init(folder_photo,folder_sketch);
	
	unsigned char**photo_u=qx_allocu(h,w);
	unsigned char**sketch_u=qx_allocu(h,w);

	qx_loadimage_png("test.png",photo_u[0],h,w,false);
	ssd.process(sketch_u,photo_u);	
	saveimage_pgm("out.pgm",sketch_u,h,w);
	

	qx_freeu(photo_u);		photo_u=NULL;
	qx_freeu(sketch_u);		sketch_u=NULL;
}