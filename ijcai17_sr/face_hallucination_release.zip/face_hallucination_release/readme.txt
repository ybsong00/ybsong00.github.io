This is the approximated implementation of our face hallucination method written by Yibing Song. It does not include the component segmentation step to facilitate the program run on your side.

Currently, it supports upscaling image with a factor of 4.

The implementation is based on matlab and C++ code. In the following, I will show you how to use this code.

1. The test image is in test_set/test.png. Run code/SRCNN/demo_SR.m and you will obtain test_set/test_srcnn.png
2. Run code/face_hallucination.sln and you will obtain test_set/test_resynthesis.pgm.
3. Run code/Refinement/refine_pp.m and you will obtain test_set/output.png.

If you use this code, please cite the following papers:

1). Face Photo-Sketch Synthesis and Recognition. Wang et al. PAMI 2009.
2). Learning to Hallucinate Face Images via Component Generation and Enhancement. IJCAI 2017.

Problems? Contact: dynamicstevenson@gmail.com