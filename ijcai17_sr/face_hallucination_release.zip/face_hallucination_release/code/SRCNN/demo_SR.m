%% The code is from SRCNN http://mmlab.ie.cuhk.edu.hk/projects/SRCNN.html
% The input is a low resolution image (60*80) in this case and output is 4x
% larger.

%% 
clear all;
clc;

im=imread('../../test_set/test.png');
up_scale=4;
model='model/x4.mat';

if size(im,3)>1
    im_ycbcr=rgb2ycbcr(im);
    im=im_ycbcr(:,:,1);
end
im=imresize(im,4,'bicubic');

im_gnd=double(im);
im_gnd=single(im_gnd)/255;
im_h = SRCNN(model, im_gnd);
imwrite(im_h,'../../test_set/test_srcnn.png');

