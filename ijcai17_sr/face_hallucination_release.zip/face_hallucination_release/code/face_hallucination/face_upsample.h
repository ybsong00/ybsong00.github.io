#ifndef FACE_UPSAMPLE_H
#define FACE_UPSAMPLE_H
#include "source_file.h"

class face_hallucination
{
public:
	face_hallucination();
	~face_hallucination();
	void clean();
	int init(char*folder_low,char*folder_high,int training_num,int search_radius=5,int border=20,int radius_denoising=8,int nr_candidate=5,double sigma_spatial=0.05);	
	int process(unsigned char**out,unsigned char**in);

private:
	void image_padding(unsigned char**out,unsigned char**in,int h_add,int w_add,int h,int w,int border);
	void initial_image(unsigned char**in);
	void knn_search();
	void compute_X();
	void denoising(unsigned char**out);

	int m_training_num,m_h,m_w,m_h_add,m_w_add,m_search_radius,m_add_border,m_candidate_num,m_denoise_radius,m_roi[4];
	double m_sigma_spatial,m_mean_of_training;

	unsigned char**m_load_image,**m_test_photo,**m_test_photo_add;
	unsigned char***m_training_photo_low_add,***m_training_photo_high_add;

	double***m_temp_nc;
	unsigned char***m_temp_u2;
	double***m_temp_d2;
	int***m_temp_i2;
	double***m_min_cost_pool;
	int***m_disparity_pool;
	search_shift_vector***m_shift_vector;

	double**m_AtA,*m_AtB,***m_xx;	
	qx_conjugated_gradient_double m_cg;
};


#endif