#include "source_file.h"
#include "face_upsample.h"
void face_hallucination_release();

void main()
{		
	face_hallucination_release();
}

void face_hallucination_release()
{
	char str[900];	int str_len=900;
	char str_train1[900],str_train2[900];
	int h,w;
	int training_num=88;

	char*folder="../../training_set/";
	sprintf_s(str,str_len,"%s/high/001.png",folder);
	qx_image_size_png(str,h,w);

	unsigned char**image_u=qx_allocu(h,w);
	unsigned char**out_u=qx_allocu(h,w);

	sprintf_s(str_train1,str_len,"../../training_set/SRCNN/");
	sprintf_s(str_train2,str_len,"../../training_set/high/");

	face_hallucination s;
	s.init(str_train1,str_train2,training_num);

	qx_loadimage_png("../../test_set/test_srcnn.png",image_u[0],h,w,false);
	s.process(out_u,image_u);
	saveimage_pgm("../../test_set/test_resynthesis.pgm",out_u,h,w);

	qx_freeu(image_u);		image_u=NULL;
	qx_freeu(out_u);		out_u=NULL;
}