clear all;
clc;

r = 1;
eps = 0.05;

up_scale=4;
im=imread('../../test_set/test.png');
im_ycbcr=rgb2ycbcr(im);
imout_cb=imresize(im_ycbcr(:,:,2),up_scale,'bicubic');
imout_cr=imresize(im_ycbcr(:,:,3),up_scale,'bicubic');

im2=im2double(imread('../../test_set/test_resynthesis.pgm'));
im1=im2double(imread('../../test_set/test_srcnn.png'));
im2_B=guidedfilter(im2,im2,r,eps);
im2_D=im2-im2_B;
im1_B=guidedfilter(im2,im1,r,eps);
im_ours=im1_B+im2_D; 
imout_y=uint8(im_ours*256);

[h,w,~]=size(imout_y);
imout=uint8(zeros(h,w,3));
imout(:,:,1)=imout_y;
imout(:,:,2)=imout_cb;
imout(:,:,3)=imout_cr;
imout=ycbcr2rgb(imout);

imwrite(imout,'../../test_set/output.png');
